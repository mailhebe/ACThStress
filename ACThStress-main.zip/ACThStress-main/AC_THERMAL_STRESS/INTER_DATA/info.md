# Here goes intermediate results that are not relevant to the final user
## Should not be used by user
## Only for troubleshooting