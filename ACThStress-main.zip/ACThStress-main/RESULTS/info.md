# Here goes the results of the different calculation
## User can use it
## Needed to recover calculation results in GUI mode
